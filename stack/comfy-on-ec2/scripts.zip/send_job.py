#!/usr/bin/env python3
import os
import json
import sys
from dotenv import load_dotenv
from comfy_utils import ComfyWorkflow
from comfy_utils import AutoScalingManager

def call_sqs(prompt_data, region, queue_name, asg_name):
    manager = AutoScalingManager(region=region, queue_name=queue_name, asg_name=asg_name)
    if manager.send_message(prompt_data):
        print("Job submitted successfully")
    else:
        print("Failed to submit job")
    # 执行初始扩缩容检查
    manager.manage_scaling_policy_without_capacity()

if __name__ == "__main__":
    # 获取环境变量
    load_dotenv('./env')
    env = os.getenv('ENV', 'base')
    prefix = os.getenv('PREFIX', 'simple-comfy')
    queue_name = os.getenv('SQS_NAME', f"{prefix}-{env}-queue")
    asg_name = os.getenv('ASG_NAME', f"{prefix}-{env}-asg")
    region = os.getenv('REGION', 'us-east-1')

    if len(sys.argv) > 1 and sys.argv[1] == "download_demo_model":
        # 这里演示提交shell执行脚本，让 parse_job.py 脚本在服务器环境执行命令，如想在base环境中下载相关的模型文件，当然也可以直接登录ssh处理：
        download_models = {
            "https://huggingface.co/linsg/AWPainting_v1.5.safetensors/resolve/main/AWPainting_v1.5.safetensors?download=true": "/home/ubuntu/comfy/ComfyUI/models/checkpoints/AWPainting_v1.5.safetensors",
            "https://huggingface.co/hakurei/waifu-diffusion-v1-4/resolve/main/vae/kl-f8-anime2.ckpt?download=true": "/home/ubuntu/comfy/ComfyUI/models/vae/kl-f8-anime2.ckpt",
            "https://huggingface.co/ac-pill/upscale_models/resolve/main/RealESRGAN_x4plus_anime_6B.pth?download=true": "/home/ubuntu/comfy/ComfyUI/models/upscale_models/RealESRGAN_x4plus_anime_6B.pth",
            "https://huggingface.co/lllyasviel/ControlNet-v1-1/resolve/main/control_v11f1e_sd15_tile.pth?download=true": "/home/ubuntu/comfy/ComfyUI/models/controlnet/control_v11f1e_sd15_tile.pth",
            "https://huggingface.co/Comfy-Org/stable-diffusion-v1-5-archive/resolve/main/v1-5-pruned-emaonly-fp16.safetensors?download=true": "/home/ubuntu/comfy/ComfyUI/models/checkpoints/v1-5-pruned-emaonly-fp16.safetensors",
        }
        for url, local_path in download_models.items():
            execute_data = {"exec_cmd": f"wget '{url}' -O {local_path}"}
            call_sqs(execute_data, region=region, queue_name=queue_name, asg_name=asg_name)

    # 提交测试的 simple_workflow.json 工作流例子
    with open('simple_workflow.json', 'r', encoding="utf-8") as f:
        prompt_data = json.load(f)
        # 设置输入参数等
        prompt_data["6"]["inputs"]["text"] = "beautiful scenery nature glass bottle landscape, , purple galaxy bottle,"
        if True:
            # 发送 sqs 方式
            call_sqs(prompt_data, region=region, queue_name=queue_name, asg_name=asg_name)
        else:
            # 直接调用comfyui的接口，获取生成文件并保存到本地
            workflow = ComfyWorkflow(server_address='1.2.3.4:8188')
            workflow.generate_clip(prompt_data)
